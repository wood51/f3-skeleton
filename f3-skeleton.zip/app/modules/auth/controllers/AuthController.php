<?php
class AuthController {
    /**
     * @route("GET /auth")
     */
    function index() {
        echo "Hello Auth !!!!";
    }
}