<?php
class BaseController {
    /**
     * @route("GET /")
     */
    function base_index() {
        echo "Hello Index !!!!";
    }
}